# Express-pairing-code
Baileys Session Gen Using Express


session.guruapi.tech is using this repo , so don't disturb me by asking if i use any other repo for session 

![image](https://github.com/user-attachments/assets/4d45804c-3d44-4f54-b74d-95617f28e2ef)
